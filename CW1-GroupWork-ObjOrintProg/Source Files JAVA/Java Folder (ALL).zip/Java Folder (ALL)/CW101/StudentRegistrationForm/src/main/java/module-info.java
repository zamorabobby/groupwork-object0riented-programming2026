module com.mycompany.studentregistrationform {
    requires javafx.controls;
    exports com.mycompany.studentregistrationform;
}
